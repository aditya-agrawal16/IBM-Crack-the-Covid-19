# IBM-crack-the-covid19

Backend used for the project is FLASK.

templates contain two HTML files.

styling is  contained in static/css
